//
//  MarsRoom.swift
//  MarsAndMore
//
//  Created by Michael Adams on 2/2/22.
//

import SwiftUI

struct MarsRoom: View {
    var body: some View {
        Text("Mars Room")
    }
}

struct MarsRoom_Previews: PreviewProvider {
    static var previews: some View {
        MarsRoom()
    }
}
